# User Images

This is used when creating users with images. If you don't do that, feel free to
delete this directory.
