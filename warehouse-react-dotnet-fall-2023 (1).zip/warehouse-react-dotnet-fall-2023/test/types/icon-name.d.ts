// This file is a fallback until you run npm run build:icons

export type IconName = string
