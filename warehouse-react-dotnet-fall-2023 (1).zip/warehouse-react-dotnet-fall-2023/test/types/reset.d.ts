// Do not add any other lines of code to this file!
import '@total-typescript/ts-reset/dom'
