# Favicon

This directory has a few versions of icons to account for different devices. In
some cases, we cannot reliably detect light/dark mode preference. Hence some of
the icons in here should not have a transparent background. These icons are
referenced in the `site.webmanifest` file.

Note, there's also a `favicon.ico` in the root of `/public` which some older
browsers will request automatically. This is a fallback for those browsers.
