export default function PrivacyRoute() {
	return <div>Privacy</div>
}
