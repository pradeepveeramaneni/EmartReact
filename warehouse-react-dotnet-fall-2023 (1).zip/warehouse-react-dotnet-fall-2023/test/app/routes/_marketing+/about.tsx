export default function AboutRoute() {
	return <div>About page</div>
}
