export default function SupportRoute() {
	return <div>Support</div>
}
