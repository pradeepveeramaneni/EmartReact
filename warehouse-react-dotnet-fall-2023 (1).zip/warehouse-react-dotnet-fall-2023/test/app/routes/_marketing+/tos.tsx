export default function TermsOfServiceRoute() {
	return <div>Terms of service</div>
}
