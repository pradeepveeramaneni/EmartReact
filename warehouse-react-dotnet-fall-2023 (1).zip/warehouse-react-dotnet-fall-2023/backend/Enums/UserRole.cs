namespace Backend.Enums;

public enum UserRole
{
    Customer = 1,
    Employee = 2,
    Owner = 3
}