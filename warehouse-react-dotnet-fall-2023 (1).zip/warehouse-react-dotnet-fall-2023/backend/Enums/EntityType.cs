namespace Backend.Enums;

public enum EntityType
{
    Stadium,
    Team,
    Sport,
    Event,
    Reservation,
    Organizer,
    Student,
    User
}