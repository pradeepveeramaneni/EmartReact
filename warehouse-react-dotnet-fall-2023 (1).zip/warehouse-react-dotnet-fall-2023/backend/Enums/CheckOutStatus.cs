namespace Backend.Enums;

public enum CheckOutStatus
{
    PENDING,
    CHECKED_OUT
}