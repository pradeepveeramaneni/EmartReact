namespace Backend.Enums;

public enum Condition
{
    NEW,
    USED
}