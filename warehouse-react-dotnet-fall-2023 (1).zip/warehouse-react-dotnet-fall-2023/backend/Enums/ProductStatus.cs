namespace Backend.Enums;

public enum ProductStatus
{
    NOT_CHECKED_IN,
    PENDING,
    CHECKED_IN,
    CHECKED_OUT,
    RETURNED
}