export enum UserRole {
	CUSTOMER = 1,
	EMPLOYEE = 2,
	// OWNER = 3,
}
