const appConfig = {
	name: "Warehouse Management System",
	logo: "/logo.png",
}

export default appConfig
