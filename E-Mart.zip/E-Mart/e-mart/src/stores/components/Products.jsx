import React from 'react'
import Mobiles from './Mobiles'
import Computers from './Computers'
import Watches from './Watches'
import Ac from './Ac'


const Products = () => {
  return (
    <div>
    <Mobiles />
    <Computers/>
    <Watches/>
    <Ac/>
    </div>
  )
}

export default Products